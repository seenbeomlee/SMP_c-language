#include <stddef.h>

int mystrlen(char *str)
{
	// Insert your code 
}

char *mystrcpy(char *toStr, char *fromStr)
{
	// Insert your code 
}

char *mystrcat(char *str1, char *str2)
{
	// Insert your code 
}

char *mystrchr(char *str, char c)
{
	// Insert your code 
}

